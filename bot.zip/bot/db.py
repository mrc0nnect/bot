import sqlite3
import json

DB_FILE = "/etc/x-ui/x-ui.db"


def get_connection(db_file):
    conn = sqlite3.connect(f"file:{db_file}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def get_client_stats(email: str):
    try:
        conn = get_connection(DB_FILE)
        cur = conn.cursor()
        cur.execute(
            "SELECT * FROM client_traffics WHERE email = (?)",
            (email,),
        )
        return cur.fetchone()

    finally:
        conn.close()


def get_inbounds_row(uuid):
    try:
        conn = get_connection(DB_FILE)
        cur = conn.cursor()
        cur.execute("SELECT * FROM inbounds")
        rows = cur.fetchall()

        for row in rows:
            settings = json.loads(row["settings"])
            clients = settings.get('clients', None)
            if clients == None:
                continue
            for client in clients:
                # print(client)
                client_id = client.get('id', None)
                if not client_id:
                    continue
                if client_id == uuid:
                    if len(clients) == 1:
                        print("for row", row)
                        return row, "row"

                    elif len(clients) > 1:
                        # stats = list(
                        #     filter(lambda x: x["email"] == client["email"], clientStats)
                        # )
                        stats = dict(get_client_stats(client["email"]))
                        print("for client", stats)
                        return stats, "client"

        return None, None
    finally:
        conn.close()
