#!/usr/bin/env python

from datetime import datetime
from uuid import UUID

from flask import Flask, render_template
from hurry.filesize import size
from khayyam import JalaliDatetime
import time

import db

app = Flask(__name__, static_url_path='/static')

@app.route("/")
def login():
    return render_template("login.html")


@app.route("/stat/<uuid>", methods=["GET", "POST"])
def stat(uuid):
    try:
        UUID(uuid)
    except ValueError:
        return render_template("panel.html", error=f"آیدی وارد شده در پنل یافت نشد")

    row, ret_type = db.get_inbounds_row(uuid)
    if row is None:
        return render_template("panel.html", error=f"آیدی وارد شده در پنل یافت نشد")

    if ret_type == "row":
        if row["expiry_time"] and int(row["expiry_time"]):
            xe = datetime.fromtimestamp(int(row["expiry_time"]) / 1000)
            xf = JalaliDatetime(xe)
            exp = f"{xe.strftime('%Y-%m-%d')} ({xf.strftime('%N/%R/%D')})"
        else:
            exp = ""

    if ret_type == "client":
        if row["expiry_time"] and int(row["expiry_time"]):
            xe = datetime.fromtimestamp(int(row["expiry_time"]) / 1000)
            xf = JalaliDatetime(xe)
            exp = f"{xe.strftime('%Y-%m-%d')} ({xf.strftime('%N/%R/%D')})"
        else:
            exp = ""

    consumed = row["down"] + row["up"]
    finished = (row["total"] > 0 and consumed >= row["total"]) or (
        row["expiry_time"] > 0 and int(int(row["expiry_time"]) / 1000) < time.time()
    )

    try:
        percent = f"{consumed / row['total'] * 100.0:.1f} %"
    except:
        percent = f"∞ %"

    total_size = f"{round(row['total'] / (1024**3),2)} GB" if row["total"] > 1024**3 else f"{round(row['total'] / (1024**2),1)} MB"
    used_size = f"{round(consumed / (1024**3),2)} GB" if consumed > 1024**3 else f"{round(consumed / (1024**2),1)} MB"
    left_size = f"{round((row['total'] - consumed) / (1024**3),2)} GB" if row["total"] - consumed > 1024**3 else f"{round((row['total'] - consumed) / (1024**2),1)} MB"

    total_size_index = 100 # int(row["total"] / (1024**2))
    used_size_index = int(round(float(consumed / (1024**2)) / float(row["total"] / (1024**2)), 2) * 100) if row["total"] != 0 else 0
    left_size_index = int(round(float((row["total"] - consumed) / (1024**2)) / float(row["total"] / (1024**2)), 2) * 100) if row["total"] != 0 else 100
    percent_index = used_size_index # int(row["total"] - consumed / (1024**2))

    user_stats = {
        "total_traffic": total_size if row["total"] != 0 else "∞",
        "used_traffic": used_size,
        "left_traffic": left_size if row["total"] != 0 else "∞",
        "used_percentage": percent,
        "expiry_date": exp if row["total"] != 0 else "∞",
        "is_finished": "غیرفعال" if finished else "فعال",
        "total_size_index": total_size_index if row["total"] != 0 else 100,
        "used_size_index": used_size_index,
        "left_size_index": left_size_index,
        "percent_index": percent_index if row["total"] != 0 else 0,
    }
    print(user_stats)
    if finished:
        color = "#f06c6c"
    else:
        color = "#6cf0ae"
    return render_template("panel.html", user_stats=user_stats, color=color)
